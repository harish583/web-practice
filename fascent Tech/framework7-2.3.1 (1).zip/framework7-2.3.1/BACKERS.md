# Backers

<table>
  <tr>
    <td align="center" valign="middle">
      <a href="https://www.securcom.me/" target="_blank">
        <img width="200" src="https://framework7.io/i/sponsors/securcom.png">
      </a>
    </td>
    <td align="center" valign="middle">
      <a href="http://mytommy.com" target="_blank">
        <img width="200" src="https://framework7.io/i/sponsors/tommy.png">
      </a>
    </td>
  </tr>
</table>

Support Framework7 development by [pledging on Patreon](https://www.patreon.com/vladimirkharlampidi)!

### $1000 Diamond Sponsor

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?patAmt=1000.0&exp=1&u=4109762&rid=830901)

---

### $500 Platinum Sponsor

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?patAmt=500.0&exp=1&u=4109762&rid=830876)

---

### $250 Gold Sponsor

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?patAmt=250.0&exp=1&u=4109762&rid=830877)

---

### $100 Silver Sponsor
Pavol Cvengros ([securCom Inc](https://www.securcom.me/))<br>
Mason Fok ([tommy](http://mytommy.com))<br>
Juergen Schimmoeller

[Join here!](https://www.patreon.com/bePatron?patAmt=100.0&exp=1&u=4109762&rid=830841)

---

### $50+ Top Supporter

Olivier<br>
Marcelo Lopetegui L.<br>
Bearr Dayss<br>
Kris Reddy<br>
Bart DJ

[Join here!](https://www.patreon.com/bePatron?exp=1&rid=830842&u=4109762&patAmt=50.0)

---

### $10+ Thank You
Almaz Kazakov<br>
plpl<br>
Zakery Kates<br>
Dan Boschen<br>
Ferry van de Graaf<br>
Denis Bousselier<br>
Firestream<br>
Matthew Becker<br>
Timo Ernst<br>
Dave Billington

[Join here!](https://www.patreon.com/bePatron?exp=1&rid=830839&u=4109762&patAmt=10.0)

---

### $5+
jinsom<br>
Alessandro De Siro<br>
Simon MacDonald<br>
César Teixeira<br>
Firas Sleibi<br>
Garry Lowther<br>
VOUSYS<br>
Tirso Martínez Reyes<br>
Amir br<br>
Toby Allen - Ballymaloe Cookery School<br>
Henry Blackman<br>
Ruslan Skorynin

[Join here!](https://www.patreon.com/bePatron?exp=1&rid=845389&u=4109762&patAmt=5.0)
